# VINDEX Registry — Production App + PWA (Netlify-ready)

This repo is a **drop-in** Next.js App Router build that provides:
- Public inspection request intake
- Invite-only portals: Dealer/Flipper/Auction, Inspector, Admin
- Evidence upload (Supabase Storage)
- AI QC gate (completeness checks; upgradeable to vision QA)
- Admin review + kickback loop
- TACIS™ scoring engine
- Server-generated PDF reports + publish to recipient org
- PWA (installable app) with offline fallback

## 1) Environment variables
Create `.env.local`:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- Optional: `NEXT_PUBLIC_SITE_URL` (set to your deployed origin, e.g. https://vindexregistry.com)

## 2) Supabase setup
Create private buckets:
- `inspection-evidence`
- `inspection-reports`

Run SQL in `supabase/sql/*` (fill in with your actual schema + RLS policies).

Seed checklist:
```bash
npm run seed:checklist
```

## 3) Netlify deploy
- Connect repo
- Build command: `npm run build`
- Publish: `.next`
- Set env vars in Netlify dashboard
- Ensure `netlify.toml` is present

## 4) Roles
Create users in Supabase Auth, then set their role/org in `profiles`:
- dealer / flipper / auction
- inspector
- admin

## 5) PWA
- Manifest at `/manifest.json`
- Install: Android/Chrome prompt; iOS via Add to Home Screen.
- Add your real icons into `public/icons/*` (replace placeholders).
