export function computeTacis({ checklist, evidence }) {
  const DEDUCT = { MINOR: 2, MODERATE: 6, CRITICAL: 15 };
  let mii = 100, sai = 100, oci = 100;
  let minor = 0, moderate = 0, critical = 0, redFlags = 0;

  checklist.forEach(r => {
    if (r.severity === "PASS") return;
    if (r.severity === "MINOR") minor++;
    if (r.severity === "MODERATE") moderate++;
    if (r.severity === "CRITICAL") critical++;
    if (r.layer === "Risk" && r.severity !== "PASS") redFlags++;

    const deduct = DEDUCT[r.severity] || 0;
    if (r.layer === "Mechanical") mii -= deduct;
    if (r.layer === "Structural") sai -= deduct;
    if (r.layer === "Operational" || r.layer === "Cosmetic") oci -= deduct;
  });

  mii = Math.max(0, Math.min(100, mii));
  sai = Math.max(0, Math.min(100, sai));
  oci = Math.max(0, Math.min(100, oci));

  let cvm = (minor * 0.004) + (moderate * 0.01) + (critical * 0.02) + (redFlags * 0.03);
  cvm = Math.min(0.35, cvm);

  const baseScore = (mii * 0.40) + (sai * 0.35) + (oci * 0.25);
  let finalScore = baseScore * (1 - cvm);

  if (redFlags >= 3 && finalScore > 69) finalScore = 69;
  finalScore = Math.round(finalScore);

  let band = "VERIFIED CRITICAL™";
  if (finalScore >= 90) band = "VERIFIED PRIME™";
  else if (finalScore >= 80) band = "VERIFIED SOLID™";
  else if (finalScore >= 70) band = "VERIFIED WATCH™";
  else if (finalScore >= 60) band = "VERIFIED RISK™";

  return { mii, sai, oci, cvm: Number(cvm.toFixed(2)), finalScore, band };
}
