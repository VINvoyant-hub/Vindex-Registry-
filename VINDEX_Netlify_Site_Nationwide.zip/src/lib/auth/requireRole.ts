import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

export async function requireRole(allowed: Array<"dealer"|"flipper"|"auction"|"inspector"|"admin">) {
  const supabase = supabaseServer();
  const { data } = await supabase.auth.getUser();
  if (!data.user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("role, org_id, full_name")
    .eq("id", data.user.id)
    .single();

  if (!profile || !allowed.includes(profile.role)) redirect("/login");
  return profile;
}
