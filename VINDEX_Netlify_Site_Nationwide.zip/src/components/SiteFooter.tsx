export default function SiteFooter() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="grid cols-3">
          <div>
            <div className="mono" style={{letterSpacing:".25em", textTransform:"uppercase", color:"rgba(255,255,255,.78)", fontSize:12}}>
              <span style={{color:"var(--gold)", fontWeight:700}}>VINDEX</span> REGISTRY™
            </div>
            <p className="small" style={{marginTop:10}}>
              National vehicle condition verification authority. Independent, standardized, audit-ready.
            </p>
          </div>
          <div>
            <p className="small mono" style={{letterSpacing:".2em", textTransform:"uppercase"}}>Portals</p>
            <p className="small" style={{marginTop:10}}>Dealers • Flippers • Auctions • Inspectors • Admin</p>
            <p className="small" style={{marginTop:10}}>Invite-only access. Public requests accepted.</p>
          </div>
          <div>
            <p className="small mono" style={{letterSpacing:".2em", textTransform:"uppercase"}}>Contact</p>
            <p className="small" style={{marginTop:10}}>Use the Request page to submit inventory for verification.</p>
            <p className="small" style={{marginTop:10, color:"rgba(201,162,74,.9)"}}>VERIFY BEYOND GUESSWORK™</p>
          </div>
        </div>
        <p className="small" style={{marginTop:26, color:"rgba(255,255,255,.45)"}}>
          © {new Date().getFullYear()} VINDEX Registry. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
