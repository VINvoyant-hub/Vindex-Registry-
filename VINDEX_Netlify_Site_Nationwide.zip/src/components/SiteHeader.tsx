import Link from "next/link";

export default function SiteHeader() {
  return (
    <div className="nav">
      <div className="container">
        <div className="nav-inner">
          <Link href="/" className="mono" style={{letterSpacing:".25em", textTransform:"uppercase", color:"rgba(255,255,255,.78)", fontSize:12}}>
            <span style={{color:"var(--gold)", fontWeight:700}}>VINDEX</span> REGISTRY™
          </Link>
          <div className="nav-links">
            <Link href="/standards">Standards</Link>
            <Link href="/programs">Programs</Link>
            <Link href="/pricing">Pricing</Link>
            <Link href="/enterprise">Enterprise</Link>
            <Link href="/regions">Nationwide</Link>
            <Link href="/request" style={{color:"rgba(201,162,74,.9)"}}>Request</Link>
            <Link href="/app/dashboard">Open App</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
