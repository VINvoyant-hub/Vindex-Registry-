import { NextResponse } from "next/server";
import { PDFDocument, StandardFonts } from "pdf-lib";
import { supabaseService } from "@/lib/supabase/service";

export async function POST(req: Request) {
  const { inspection_id } = await req.json();
  const supabase = supabaseService();

  const { data: insp, error: iErr } = await supabase
    .from("inspections")
    .select("id, org_id, status, inventory:inventory_id(vin,year,make,model,trim,mileage,location_text)")
    .eq("id", inspection_id)
    .single();
  if (iErr || !insp) return NextResponse.json({ error: iErr?.message ?? "not found" }, { status: 404 });
  if (insp.status !== "approved") return NextResponse.json({ error: "Inspection must be approved before PDF generation." }, { status: 400 });

  const { data: score } = await supabase.from("scores").select("*").eq("inspection_id", inspection_id).single();
  const { data: aiqc } = await supabase.from("ai_qc").select("*").eq("inspection_id", inspection_id).single();
  const { data: results } = await supabase.from("checklist_results").select("item_code,severity,notes").eq("inspection_id", inspection_id);

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  let y = 740;
  const draw = (txt: string, size = 12, isBold = false) => {
    page.drawText(txt, { x: 50, y, size, font: isBold ? bold : font });
    y -= size + 10;
  };

  draw("VINDEX REGISTRY™", 18, true);
  draw("Inspection Report (Server-Generated)", 12, false);
  y -= 10;

  draw(`VIN: ${insp.inventory.vin}`, 12, true);
  draw(`Vehicle: ${insp.inventory.year ?? ""} ${insp.inventory.make ?? ""} ${insp.inventory.model ?? ""} ${insp.inventory.trim ?? ""}`, 11);
  draw(`Mileage: ${insp.inventory.mileage ?? "—"}`, 11);
  draw(`Location: ${insp.inventory.location_text ?? "—"}`, 11);

  y -= 10;
  draw(`VINDEX Score™: ${score?.vindex_score ?? "—"}  ${score?.band ?? ""}`, 13, true);
  draw(`Confidence Grade™: ${score?.confidence ?? "—"}`, 11);
  draw(`MII™ ${score?.mii ?? "—"}   SAI™ ${score?.sai ?? "—"}   OCI™ ${score?.oci ?? "—"}   CVM™ ${score?.cvm ?? "—"}`, 11);

  y -= 10;
  draw(`AI QC: ${aiqc?.status ?? "—"} (score ${aiqc?.score ?? "—"})`, 11, true);
  if (aiqc?.issues?.length) {
    draw("AI QC Issues:", 11, true);
    for (const it of aiqc.issues.slice(0, 6)) draw(`- ${it.code}: ${it.msg}`, 10);
  }

  y -= 10;
  draw("Checklist Summary (sample):", 11, true);
  for (const r of (results ?? []).slice(0, 12)) draw(`- ${r.item_code}: ${r.severity}`, 10);
  draw("… full checklist retained in system record.", 10);

  const bytes = await pdf.save();

  const bucket = "inspection-reports";
  const path = `${inspection_id}/VINDEX_Report_${insp.inventory.vin}.pdf`;

  const up = await supabase.storage.from(bucket).upload(path, bytes, { contentType: "application/pdf", upsert: true });
  if (up.error) return NextResponse.json({ error: up.error.message }, { status: 500 });

  await supabase.from("reports").upsert({
    inspection_id,
    published_to_org: insp.org_id,
    pdf_bucket: bucket,
    pdf_path: path,
    published_at: new Date().toISOString(),
  });

  await supabase.from("inspections").update({ status: "published_to_recipient" }).eq("id", inspection_id);

  return NextResponse.json({ ok: true, bucket, path });
}
