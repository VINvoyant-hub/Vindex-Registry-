import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseService } from "@/lib/supabase/service";

const Schema = z.object({
  email: z.string().email(),
  orgName: z.string().min(2),
  orgType: z.enum(["dealer","flipper","auction"]).default("dealer"),
  contactName: z.string().optional(),
  phone: z.string().optional(),
  vin: z.string().min(11).max(17),
  year: z.coerce.number().optional(),
  make: z.string().optional(),
  model: z.string().optional(),
  trim: z.string().optional(),
  mileage: z.coerce.number().optional(),
  locationText: z.string().min(3),
  notes: z.string().optional()
});

export async function POST(req: Request) {
  const supabase = supabaseService();
  const body = await req.json();
  const parsed = Schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const p = parsed.data;
  const vin = p.vin.trim().toUpperCase();

  const { data: pr, error: prErr } = await supabase
    .from("public_requests")
    .insert({
      email: p.email,
      org_name: p.orgName,
      org_type: p.orgType,
      contact_name: p.contactName ?? null,
      phone: p.phone ?? null,
      vin,
      year: p.year ?? null,
      make: p.make ?? null,
      model: p.model ?? null,
      trim: p.trim ?? null,
      mileage: p.mileage ?? null,
      location_text: p.locationText,
      notes: p.notes ?? null,
    })
    .select("id")
    .single();

  if (prErr) return NextResponse.json({ error: prErr.message }, { status: 500 });

  try {
    const { data: org, error: orgErr } = await supabase
      .from("orgs")
      .upsert({ name: p.orgName, org_type: p.orgType }, { onConflict: "name" })
      .select("id")
      .single();
    if (orgErr) throw new Error(orgErr.message);

    const { data: inv, error: invErr } = await supabase
      .from("inventory")
      .upsert({
        org_id: org.id,
        vin,
        year: p.year ?? null,
        make: p.make ?? null,
        model: p.model ?? null,
        trim: p.trim ?? null,
        mileage: p.mileage ?? null,
        location_text: p.locationText,
        notes: p.notes ?? null,
      }, { onConflict: "org_id,vin" })
      .select("id")
      .single();
    if (invErr) throw new Error(invErr.message);

    const { data: insp, error: inspErr } = await supabase
      .from("inspections")
      .insert({ org_id: org.id, inventory_id: inv.id, status: "inspection_requested" })
      .select("id")
      .single();
    if (inspErr) throw new Error(inspErr.message);

    await supabase.from("public_requests").update({ status: "created", created_inspection_id: insp.id }).eq("id", pr.id);
    return NextResponse.json({ ok: true, requestId: pr.id, inspectionId: insp.id });
  } catch (e: any) {
    await supabase.from("public_requests").update({ status: "error", error: e?.message ?? "unknown" }).eq("id", pr.id);
    return NextResponse.json({ ok: false, error: e?.message ?? "unknown" }, { status: 500 });
  }
}
