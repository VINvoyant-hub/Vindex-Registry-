import { NextResponse } from "next/server";
import { supabaseService } from "@/lib/supabase/service";

export async function POST(req: Request) {
  const { inspection_id } = await req.json();
  const supabase = supabaseService();

  const { data: evidence } = await supabase.from("evidence").select("id,kind").eq("inspection_id", inspection_id);
  const { data: results } = await supabase.from("checklist_results").select("id").eq("inspection_id", inspection_id);

  const issues: any[] = [];
  if ((evidence?.length ?? 0) < 12) issues.push({ code: "EVIDENCE_MINIMUM", msg: "Insufficient evidence count." });
  if ((results?.length ?? 0) < 120) issues.push({ code: "CHECKLIST_INCOMPLETE", msg: "Checklist coverage below threshold." });

  const pass = issues.length === 0;

  await supabase.from("ai_qc").upsert({
    inspection_id,
    status: pass ? "pass" : "fail",
    score: pass ? 95 : 60,
    issues
  });

  await supabase.from("inspections").update({ status: "admin_review" }).eq("id", inspection_id);
  return NextResponse.json({ ok: true, pass, issues });
}
