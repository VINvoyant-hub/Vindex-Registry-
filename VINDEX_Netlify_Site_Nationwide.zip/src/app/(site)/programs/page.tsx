export default function Programs() {
  return (
    <main className="container" style={{padding:"46px 0"}}>
      <div className="badge">Certification • Licensing • Prestige</div>
      <h1 className="h1" style={{fontSize:44}}>National programs</h1>
      <p className="p" style={{maxWidth:860}}>
        VINDEX scales through controlled certification. Inspectors are licensed under VINDEX standards, while scoring and publication
        remain governed by VINDEX to protect the authority model.
      </p>

      <div className="hr" />

      <div className="grid cols-3">
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>VINDEX Certified Inspector™</h2>
          <p className="small">Level I (General) • Level II (Performance) • Level III (Exotic Specialist)</p>
          <ul className="small" style={{marginTop:10, paddingLeft:18}}>
            <li>Training + calibration</li>
            <li>Evidence protocols</li>
            <li>Audit + re-certification</li>
          </ul>
        </div>

        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>VINDEX Certified Dealer™</h2>
          <p className="small">Earn trust through verified inventory and consistent disclosures.</p>
          <ul className="small" style={{marginTop:10, paddingLeft:18}}>
            <li>Badge + directory</li>
            <li>Preferred scheduling</li>
            <li>Operational standards</li>
          </ul>
        </div>

        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Auction Partnership Track</h2>
          <p className="small">Arbitration reduction + condition intelligence reporting.</p>
          <ul className="small" style={{marginTop:10, paddingLeft:18}}>
            <li>Lane-ready verification</li>
            <li>Data exports/API</li>
            <li>Revenue share models</li>
          </ul>
        </div>
      </div>

      <div className="hr" />

      <div className="card">
        <h2 className="h2">Performance & exotic specialization</h2>
        <p className="p" style={{marginTop:8}}>
          VINDEX’s specialization program standardizes what “high-performance verification” means across the country:
          track-use indicators, high-temperature wear, carbon ceramics, suspension tolerances, and calibration-sensitive ADAS systems.
        </p>
      </div>
    </main>
  );
}
