export default function Pricing() {
  return (
    <main className="container" style={{padding:"46px 0"}}>
      <div className="badge">Pricing • Packages • Tiers</div>
      <h1 className="h1" style={{fontSize:44}}>Simple pricing, premium outcomes</h1>
      <p className="p" style={{maxWidth:860}}>
        Pricing can be configured by market and vehicle class. These are suggested institutional tiers
        aligned to the VINDEX authority positioning.
      </p>

      <div className="hr" />

      <div className="grid cols-3">
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Core Verification</h2>
          <p className="small">CVP™ 147 + TACIS™ score + PDF + portal storage</p>
          <p className="kpi" style={{fontSize:26, marginTop:10}}>$399–$599</p>
          <p className="small">Ideal for standard dealer and flipper inventory.</p>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Performance Tier</h2>
          <p className="small">Enhanced wear indicators + calibration notes + risk focus</p>
          <p className="kpi" style={{fontSize:26, marginTop:10}}>$699–$999</p>
          <p className="small">For AMG / M / RS / GT / track-oriented vehicles.</p>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Exotic Specialist</h2>
          <p className="small">Specialist inspector + increased evidence + higher scrutiny</p>
          <p className="kpi" style={{fontSize:26, marginTop:10}}>$1,199–$2,499</p>
          <p className="small">Ferrari / Lamborghini / McLaren / Porsche GT / etc.</p>
        </div>
      </div>

      <div className="hr" />
      <div className="card">
        <h2 className="h2">Enterprise</h2>
        <p className="p" style={{marginTop:8}}>
          Auctions and large dealers can integrate VINDEX as a verification layer with revenue share,
          custom SLAs, data exports, and arbitration reduction programs.
        </p>
      </div>
    </main>
  );
}
