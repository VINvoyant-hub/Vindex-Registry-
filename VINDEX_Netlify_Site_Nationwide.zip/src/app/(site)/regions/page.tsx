export default function Regions() {
  return (
    <main className="container" style={{padding:"46px 0"}}>
      <div className="badge">Nationwide • Controlled scaling</div>
      <h1 className="h1" style={{fontSize:44}}>Nationwide by design</h1>
      <p className="p" style={{maxWidth:860}}>
        VINDEX scales nationally through certification tiers and standardized evidence governance.
        We activate regions in performance hubs first, then extend coverage as inspector quality is validated.
      </p>

      <div className="hr" />

      <div className="grid cols-3">
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Wave 1</h2>
          <p className="small">Performance hubs</p>
          <p className="small" style={{marginTop:10}}>Los Angeles • Scottsdale • Dallas • Miami • NYC • Chicago</p>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Wave 2</h2>
          <p className="small">Auction pilot expansion</p>
          <p className="small" style={{marginTop:10}}>Regional auction groups + independent lanes</p>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Wave 3</h2>
          <p className="small">National coverage</p>
          <p className="small" style={{marginTop:10}}>Certified inspector licensing + audit cadence</p>
        </div>
      </div>
    </main>
  );
}
