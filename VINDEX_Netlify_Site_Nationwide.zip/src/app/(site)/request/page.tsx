"use client";
import { useState } from "react";

export default function PublicRequestPage() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMsg(null);
    const form = new FormData(e.currentTarget);
    const payload: any = {};
    form.forEach((v,k)=> payload[k]=v);

    const res = await fetch("/api/public/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const json = await res.json();
    setLoading(false);

    if (!res.ok) return setMsg("Submission failed. Please try again.");
    setMsg("Request received. VINDEX will confirm scheduling shortly.");
  }

  return (
    <main className="min-h-screen bg-[#050608] text-white">
      <div className="mx-auto max-w-2xl px-6 py-14">
        <h1 className="text-3xl font-semibold">Request Inspection</h1>
        <p className="mt-2 text-sm text-white/65">Public submission. Portal access is provisioned by invite.</p>

        <form onSubmit={submit} className="mt-8 space-y-4 rounded-2xl border border-white/10 bg-white/5 p-6">
          <input name="email" placeholder="Email" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" required />
          <input name="orgName" placeholder="Company / Dealer / Auction Name" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" required />
          <select name="orgType" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" defaultValue="dealer">
            <option value="dealer">Dealer</option>
            <option value="flipper">Flipper</option>
            <option value="auction">Auction</option>
          </select>

          <input name="contactName" placeholder="Contact name (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />
          <input name="phone" placeholder="Phone (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input name="vin" placeholder="VIN" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" required />
            <input name="year" placeholder="Year (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />
            <input name="make" placeholder="Make (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />
            <input name="model" placeholder="Model (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />
            <input name="trim" placeholder="Trim (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />
            <input name="mileage" placeholder="Mileage (optional)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />
          </div>

          <input name="locationText" placeholder="Location (auction / lot / address)" className="w-full rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" required />
          <textarea name="notes" placeholder="Notes (optional)" className="w-full min-h-[120px] rounded-xl bg-black/40 px-4 py-3 text-sm border border-white/10" />

          <button disabled={loading} className="w-full rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm hover:bg-white/10 disabled:opacity-50">
            {loading ? "Submitting…" : "Submit Request"}
          </button>

          {msg ? <p className="text-sm text-white/70">{msg}</p> : null}
        </form>
      </div>
    </main>
  );
}
