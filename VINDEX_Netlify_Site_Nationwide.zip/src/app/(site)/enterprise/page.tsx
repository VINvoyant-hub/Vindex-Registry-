export default function Enterprise() {
  return (
    <main className="container" style={{padding:"46px 0"}}>
      <div className="badge">Auctions • Integrations • Data</div>
      <h1 className="h1" style={{fontSize:44}}>Enterprise partnerships</h1>
      <p className="p" style={{maxWidth:860}}>
        VINDEX is designed to plug into dealer and auction workflows: inventory uploads, inspection assignment,
        AI QC gating, governed scoring, and instant PDF publishing to the right party.
      </p>

      <div className="hr" />

      <div className="grid cols-2">
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Auction-ready verification</h2>
          <ul className="p" style={{paddingLeft:18, marginTop:10}}>
            <li>Lane scheduling + inspector routing</li>
            <li>Arbitration risk flags (structural / safety / identity)</li>
            <li>Condition intelligence exports</li>
            <li>Revenue share structures</li>
          </ul>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>Integration architecture</h2>
          <p className="small">
            The platform supports multi-tenant orgs, role-based access control, secure file storage,
            and a clean publish flow. Data can be exported via APIs or scheduled reports.
          </p>
          <p className="small" style={{marginTop:12}}>
            Target systems: DMS/CRM, auction inventory feeds, warranty underwriting, lender risk models.
          </p>
        </div>
      </div>
    </main>
  );
}
