import Link from "next/link";

export default function Home() {
  return (
    <main>
      <section className="container" style={{padding:"54px 0 10px"}}>
        <div className="badge">National Verification Authority • Invite-only Portals</div>
        <h1 className="h1">Vehicle condition verification — standardized, audit-ready, scalable.</h1>
        <p className="p" style={{maxWidth:780}}>
          VINDEX Registry is the independent authority for pre- and post-purchase inspections across dealers, flippers, and auctions.
          Every inspection is scored with <b style={{color:"var(--gold)"}}>TACIS™</b>, validated through AI quality controls, reviewed by admin,
          and published as a server-generated report into your private portal.
        </p>

        <div style={{display:"flex", gap:12, flexWrap:"wrap", marginTop:22}}>
          <Link className="btn primary" href="/request">Request an Inspection</Link>
          <Link className="btn" href="/app/dashboard">Open App</Link>
          <Link className="btn" href="/standards">See TACIS™ + CVP™</Link>
        </div>

        <div className="hr" />
      </section>

      <section className="container" style={{padding:"0 0 22px"}}>
        <div className="grid cols-3">
          <div className="card">
            <div className="mono small" style={{letterSpacing:".25em", textTransform:"uppercase"}}>Protocol</div>
            <div className="kpi" style={{marginTop:10}}>CVP™ 147</div>
            <p className="small">A 147-point standardized checklist with identity, mechanical, structural, operational, cosmetic, and risk layers.</p>
          </div>
          <div className="card">
            <div className="mono small" style={{letterSpacing:".25em", textTransform:"uppercase"}}>Scoring</div>
            <div className="kpi" style={{marginTop:10}}>TACIS™</div>
            <p className="small">Layer-weighted scoring + CVM™ volatility modifier + red-flag governance to prevent “pretty reports” masking risk.</p>
          </div>
          <div className="card">
            <div className="mono small" style={{letterSpacing:".25em", textTransform:"uppercase"}}>Governance</div>
            <div className="kpi" style={{marginTop:10}}>AI QC</div>
            <p className="small">Evidence completeness, photo clarity gating, and compliance checks before admin review and publishing.</p>
          </div>
        </div>
      </section>

      <section className="container" style={{padding:"26px 0"}}>
        <div className="grid cols-2">
          <div className="card">
            <h2 className="h2">How it works</h2>
            <ol className="p" style={{paddingLeft:18, marginTop:8}}>
              <li><b>Submit</b> inventory via Request page or in-portal upload.</li>
              <li><b>Inspect</b> by a VINDEX Certified Inspector™ using CVP™ 147.</li>
              <li><b>Validate</b> via AI QC (evidence, clarity, completeness).</li>
              <li><b>Review</b> by admin (approve or kick back revisions).</li>
              <li><b>Score</b> with TACIS™ and generate server PDF.</li>
              <li><b>Publish</b> into the recipient’s private portal.</li>
            </ol>
            <div style={{display:"flex", gap:12, flexWrap:"wrap", marginTop:18}}>
              <Link className="btn" href="/standards">Inspection Standards</Link>
              <Link className="btn" href="/enterprise">Auction Integrations</Link>
            </div>
          </div>

          <div className="card">
            <h2 className="h2">Why VINDEX is different</h2>
            <ul className="p" style={{paddingLeft:18, marginTop:8}}>
              <li><b>Authority model:</b> centralized scoring governance; inspectors execute, VINDEX verifies.</li>
              <li><b>Permanent condition ledger:</b> inspections persist by VIN + VINDEX ID.</li>
              <li><b>Performance specialization:</b> tiered inspection expertise for high-performance and exotic inventory.</li>
              <li><b>Enterprise readiness:</b> arbitration reduction, audit trails, and data outputs.</li>
            </ul>
            <div style={{marginTop:18}}>
              <Link className="btn primary" href="/programs">See Certification Tiers</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
