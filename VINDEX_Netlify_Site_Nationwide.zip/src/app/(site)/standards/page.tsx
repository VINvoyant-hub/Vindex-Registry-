export default function Standards() {
  return (
    <main className="container" style={{padding:"46px 0"}}>
      <div className="badge">Standards • Scoring • Compliance</div>
      <h1 className="h1" style={{fontSize:44}}>The VINDEX Verification Standard™</h1>
      <p className="p" style={{maxWidth:860}}>
        VINDEX is built around a consistent national protocol (CVP™ 147) and a governed scoring system (TACIS™).
        Every report is evidence-backed, AI-validated for completeness, and admin-reviewed before publication.
      </p>

      <div className="hr" />

      <div className="grid cols-3">
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>CVP™ 147 Checklist</h2>
          <p className="small">Identity • Mechanical • Structural • Operational • Cosmetic • Risk (red flags).</p>
          <p className="small" style={{marginTop:10}}>
            Coverage expectations are enforced by AI QC and admin review.
          </p>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>TACIS™ Scoring</h2>
          <p className="small">
            Computes MII™ (Mechanical), SAI™ (Structural), OCI™ (Operational/Cosmetic) and applies CVM™ volatility.
          </p>
          <p className="small" style={{marginTop:10}}>
            Red-flag governance prevents unsafe “high scores” when material risk exists.
          </p>
        </div>
        <div className="card">
          <h2 className="h2" style={{fontSize:24}}>AI Quality Control</h2>
          <p className="small">
            Evidence completeness, photo clarity, required identity captures, and checklist coverage thresholds.
          </p>
          <p className="small" style={{marginTop:10}}>
            Fails are routed back to inspectors for correction before admin final review.
          </p>
        </div>
      </div>

      <div className="hr" />

      <div className="card">
        <h2 className="h2">Bands and confidence</h2>
        <p className="p" style={{marginTop:8}}>
          Scores produce a band (VERIFIED PRIME™ → VERIFIED CRITICAL™) and a confidence grade based on evidence and coverage.
          This allows buyers and sellers to interpret the result with appropriate context.
        </p>
        <div className="grid cols-3" style={{marginTop:16}}>
          <div className="card">
            <div className="mono small">VERIFIED PRIME™</div>
            <div className="kpi">90–100</div>
            <p className="small">Top-tier condition with high confidence and minimal volatility.</p>
          </div>
          <div className="card">
            <div className="mono small">VERIFIED SOLID™</div>
            <div className="kpi">80–89</div>
            <p className="small">Strong condition with manageable findings and clear evidence.</p>
          </div>
          <div className="card">
            <div className="mono small">VERIFIED WATCH™+</div>
            <div className="kpi">0–79</div>
            <p className="small">Material findings and/or volatility. Use report + photos to price risk.</p>
          </div>
        </div>
      </div>
    </main>
  );
}
