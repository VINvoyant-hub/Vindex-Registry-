export default function OfflinePage() {
  return (
    <main className="min-h-screen bg-[#050608] text-white flex items-center justify-center px-6">
      <div className="max-w-md text-center">
        <p className="text-sm tracking-[0.25em] uppercase text-white/60">VINDEX REGISTRY™</p>
        <h1 className="mt-3 text-3xl font-semibold">You’re offline</h1>
        <p className="mt-3 text-sm text-white/65">
          Reconnect to load inspection data. The app shell is installed and ready.
        </p>
      </div>
    </main>
  );
}
