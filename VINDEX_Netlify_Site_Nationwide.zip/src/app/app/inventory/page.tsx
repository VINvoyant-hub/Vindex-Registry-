import { supabaseServer } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { createInventory } from "./actions";

export default async function InventoryPage() {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("org_id").eq("id", auth.user.id).single();
  if (!profile?.org_id) return <div className="text-white/70">No organization assigned.</div>;

  const { data: items } = await supabase
    .from("inventory")
    .select("id, vin, year, make, model, trim, mileage, created_at")
    .eq("org_id", profile.org_id)
    .order("created_at", { ascending: false })
    .limit(50);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Inventory</h1>

      <form action={async (fd: FormData) => {
        "use server";
        await createInventory({
          vin: String(fd.get("vin") || ""),
          year: String(fd.get("year") || ""),
          make: String(fd.get("make") || ""),
          model: String(fd.get("model") || ""),
          trim: String(fd.get("trim") || ""),
          mileage: String(fd.get("mileage") || ""),
          location_text: String(fd.get("location_text") || ""),
          notes: String(fd.get("notes") || ""),
        });
      }} className="rounded-2xl border border-white/10 bg-white/5 p-5 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input name="vin" placeholder="VIN" className="rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" required />
          <input name="year" placeholder="Year" className="rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
          <input name="mileage" placeholder="Mileage" className="rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
          <input name="make" placeholder="Make" className="rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
          <input name="model" placeholder="Model" className="rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
          <input name="trim" placeholder="Trim" className="rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
        </div>
        <input name="location_text" placeholder="Location (lot/auction)" className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
        <textarea name="notes" placeholder="Notes" className="w-full min-h-[90px] rounded-xl bg-black/40 border border-white/10 px-4 py-2.5 text-sm" />
        <button className="rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm hover:bg-white/10">Add Inventory</button>
      </form>

      <div className="rounded-2xl border border-white/10 bg-white/5 overflow-hidden">
        <div className="grid grid-cols-12 gap-2 px-5 py-3 text-xs tracking-[0.25em] uppercase text-white/50">
          <div className="col-span-4">Vehicle</div>
          <div className="col-span-4">VIN</div>
          <div className="col-span-2">Mileage</div>
          <div className="col-span-2">Created</div>
        </div>
        {(items ?? []).map((i) => (
          <div key={i.id} className="grid grid-cols-12 gap-2 px-5 py-4 border-t border-white/10 text-sm">
            <div className="col-span-4 text-white/80">{i.year ?? ""} {i.make ?? ""} {i.model ?? ""} {i.trim ?? ""}</div>
            <div className="col-span-4 text-white/70">{i.vin}</div>
            <div className="col-span-2 text-white/70">{i.mileage ?? "—"}</div>
            <div className="col-span-2 text-white/60">{new Date(i.created_at).toLocaleDateString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
