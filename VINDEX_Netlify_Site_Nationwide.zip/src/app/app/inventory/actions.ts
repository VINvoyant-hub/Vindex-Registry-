"use server";
import { supabaseServer } from "@/lib/supabase/server";

export async function createInventory(form: {
  vin: string;
  year?: string;
  make?: string;
  model?: string;
  trim?: string;
  mileage?: string;
  location_text?: string;
  notes?: string;
}) {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error("Unauthorized");

  const { data: profile } = await supabase.from("profiles").select("org_id").eq("id", auth.user.id).single();
  if (!profile?.org_id) throw new Error("No org assigned");

  const vin = form.vin.trim().toUpperCase();

  const { error } = await supabase.from("inventory").insert({
    org_id: profile.org_id,
    vin,
    year: form.year ? Number(form.year) : null,
    make: form.make ?? null,
    model: form.model ?? null,
    trim: form.trim ?? null,
    mileage: form.mileage ? Number(form.mileage) : null,
    location_text: form.location_text ?? null,
    notes: form.notes ?? null,
  });

  if (error) throw new Error(error.message);
}
