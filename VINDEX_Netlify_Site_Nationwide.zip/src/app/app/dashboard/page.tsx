import { supabaseServer } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

function Kpi({ title, value }: { title: string; value: string | number }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
      <p className="text-xs tracking-[0.35em] uppercase text-white/55">{title}</p>
      <p className="mt-3 text-3xl font-semibold text-[#C9A24A]">{value}</p>
    </div>
  );
}

export default async function DashboardPage() {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("org_id").eq("id", auth.user.id).single();
  if (!profile?.org_id) return <div className="text-white/70">No organization assigned yet.</div>;

  const { data: rows } = await supabase
    .from("scores")
    .select("vindex_score, band, cvm, inspections!inner(org_id)")
    .eq("inspections.org_id", profile.org_id);

  const count = rows?.length ?? 0;
  const avgScore = count ? Math.round(rows!.reduce((a, r) => a + (r.vindex_score ?? 0), 0) / count) : null;
  const avgCvm = count ? (rows!.reduce((a, r) => a + Number(r.cvm ?? 0), 0) / count).toFixed(2) : null;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] tracking-[0.35em] uppercase text-white/60">Portal</p>
        <h1 className="mt-2 text-3xl font-semibold">Dashboard</h1>
        <p className="mt-2 text-sm text-white/65">Your verified inventory and inspection outcomes.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Kpi title="Inspections Scored" value={count || "—"} />
        <Kpi title="Avg VINDEX Score™" value={avgScore ?? "—"} />
        <Kpi title="Avg CVM™" value={avgCvm ?? "—"} />
        <Kpi title="Authority Model" value="TACIS™" />
      </div>
    </div>
  );
}
