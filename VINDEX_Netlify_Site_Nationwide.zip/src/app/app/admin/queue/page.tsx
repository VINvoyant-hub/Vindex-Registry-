import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function AdminQueue() {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: prof } = await supabase.from("profiles").select("role").eq("id", auth.user.id).single();
  if (prof?.role !== "admin") redirect("/app/dashboard");

  const { data } = await supabase
    .from("inspections")
    .select("id,status,created_at,org_id,inventory:inventory_id(vin,year,make,model)")
    .in("status", ["admin_review","revisions_requested","resubmitted","ai_qc_in_review"])
    .order("created_at", { ascending: false });

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Admin Queue</h1>

      <div className="rounded-2xl border border-white/10 bg-white/5 overflow-hidden">
        <div className="grid grid-cols-12 gap-2 px-5 py-3 text-xs tracking-[0.25em] uppercase text-white/50">
          <div className="col-span-5">Vehicle</div>
          <div className="col-span-4">VIN</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-1 text-right">Open</div>
        </div>

        {(data ?? []).map((r) => (
          <div key={r.id} className="grid grid-cols-12 gap-2 px-5 py-4 border-t border-white/10 text-sm">
            <div className="col-span-5 text-white/80">{r.inventory?.year} {r.inventory?.make} {r.inventory?.model}</div>
            <div className="col-span-4 text-white/70">{r.inventory?.vin}</div>
            <div className="col-span-2 text-white/70">{r.status}</div>
            <div className="col-span-1 text-right">
              <Link href={`/app/admin/inspections/${r.id}`} className="underline text-white/80 hover:text-white">Open</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
