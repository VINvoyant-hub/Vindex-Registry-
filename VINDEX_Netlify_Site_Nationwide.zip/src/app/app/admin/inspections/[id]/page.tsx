"use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { adminApproveAndScore, adminKickback } from "./actions";

export default function AdminInspection({ params }: { params: { id: string } }) {
  const [aiqc, setAiqc] = useState<any>(null);
  const [evidenceCount, setEvidenceCount] = useState<number>(0);
  const [checklistCount, setChecklistCount] = useState<number>(0);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    (async () => {
      const supabase = supabaseBrowser();
      const a = await supabase.from("ai_qc").select("*").eq("inspection_id", params.id).single();
      setAiqc(a.data);

      const e = await supabase.from("evidence").select("id").eq("inspection_id", params.id);
      setEvidenceCount(e.data?.length ?? 0);

      const c = await supabase.from("checklist_results").select("id").eq("inspection_id", params.id);
      setChecklistCount(c.data?.length ?? 0);
    })();
  }, [params.id]);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Admin Review</h1>

      <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <p className="text-sm font-semibold">AI QC</p>
        <p className="mt-2 text-sm text-white/70">
          Status: <span className="text-[#C9A24A]">{aiqc?.status ?? "—"}</span> • Score: {aiqc?.score ?? "—"}
        </p>
        <p className="mt-1 text-sm text-white/60">Evidence: {evidenceCount} • Checklist items: {checklistCount}</p>

        {Array.isArray(aiqc?.issues) && aiqc.issues.length ? (
          <div className="mt-4 rounded-xl border border-white/10 bg-black/30 p-4">
            <p className="text-sm font-semibold">Issues</p>
            <ul className="mt-2 text-sm text-white/70 list-disc pl-5">
              {aiqc.issues.map((x: any, idx: number) => (
                <li key={idx}>{x.code}: {x.msg}</li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/5 p-6 space-y-3">
        <p className="text-sm font-semibold">Kickback Notes (if needed)</p>
        <textarea
          className="w-full min-h-[120px] rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Describe what must be corrected (missing photos, unclear VIN, incomplete checklist, etc.)"
        />
        <div className="flex gap-3">
          <button
            onClick={async () => adminKickback(params.id, notes || "Revision required.")}
            className="rounded-xl border border-white/15 px-4 py-2.5 text-sm hover:bg-white/5"
          >
            Request Revisions
          </button>

          <button
            onClick={async () => adminApproveAndScore(params.id)}
            className="rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm hover:bg-white/10"
          >
            Approve → TACIS Score → Generate PDF → Publish
          </button>
        </div>
      </div>
    </div>
  );
}
