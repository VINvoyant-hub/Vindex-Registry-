"use server";

import { supabaseService } from "@/lib/supabase/service";
import { computeTacis } from "@/lib/tacis/score";

export async function adminKickback(inspection_id: string, notes: string) {
  const supabase = supabaseService();
  await supabase.from("admin_reviews").insert({ inspection_id, decision: "needs_revision", notes });
  await supabase.from("inspections").update({ status: "revisions_requested" }).eq("id", inspection_id);
}

export async function adminApproveAndScore(inspection_id: string) {
  const supabase = supabaseService();

  const { data: checklist } = await supabase
    .from("checklist_results")
    .select("item_code,severity,notes, checklist_items!inner(layer)")
    .eq("inspection_id", inspection_id);

  const normalized = (checklist ?? []).map((r: any) => ({
    item_code: r.item_code,
    severity: r.severity,
    notes: r.notes,
    layer: r.checklist_items.layer
  }));

  const { data: evidence } = await supabase
    .from("evidence")
    .select("id,kind")
    .eq("inspection_id", inspection_id);

  const tacis = computeTacis({ checklist: normalized as any, evidence: (evidence ?? []) as any });

  await supabase.from("scores").upsert({
    inspection_id,
    mii: tacis.mii,
    sai: tacis.sai,
    oci: tacis.oci,
    cvm: tacis.cvm,
    vindex_score: tacis.finalScore,
    band: tacis.band,
    confidence: tacis.confidence
  });

  await supabase.from("admin_reviews").insert({ inspection_id, decision: "approved", notes: "Approved." });
  await supabase.from("inspections").update({ status: "approved" }).eq("id", inspection_id);

  await fetch(`${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/api/reports/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ inspection_id }),
  }).catch(() => {});
}
