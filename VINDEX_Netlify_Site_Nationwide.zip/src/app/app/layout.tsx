import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = supabaseServer();
  const { data } = await supabase.auth.getUser();
  if (!data.user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("role, full_name").eq("id", data.user.id).single();
  const role = profile?.role ?? "dealer";

  return (
    <div className="min-h-screen bg-[#050608] text-white">
      <header className="border-b border-white/10 bg-black/40">
        <div className="mx-auto max-w-6xl px-6 py-4 flex items-center justify-between">
          <Link href="/app/dashboard" className="text-sm tracking-[0.25em] uppercase text-white/70">
            <span className="text-[#C9A24A]">VINDEX</span> REGISTRY™
          </Link>
          <nav className="flex items-center gap-4 text-sm text-white/70">
            <Link href="/app/dashboard" className="hover:text-white">Dashboard</Link>
            <Link href="/app/inventory" className="hover:text-white">Inventory</Link>
            <Link href="/app/inspections" className="hover:text-white">Inspections</Link>
            {role === "inspector" ? <Link href="/app/inspector/jobs" className="hover:text-white">Inspector</Link> : null}
            {role === "admin" ? <Link href="/app/admin/queue" className="hover:text-white">Admin</Link> : null}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
    </div>
  );
}
