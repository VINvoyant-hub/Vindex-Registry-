import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function InspectionsPage() {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("org_id").eq("id", auth.user.id).single();
  if (!profile?.org_id) return <div className="text-white/70">No organization assigned.</div>;

  const { data } = await supabase
    .from("inspections")
    .select(`
      id, status, created_at,
      inventory:inventory_id(vin, year, make, model),
      scores:scores(vindex_score, band, confidence, cvm)
    `)
    .eq("org_id", profile.org_id)
    .order("created_at", { ascending: false })
    .limit(50);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Inspections</h1>

      <div className="rounded-2xl border border-white/10 bg-white/5 overflow-hidden">
        <div className="grid grid-cols-12 gap-2 px-5 py-3 text-xs tracking-[0.25em] uppercase text-white/50">
          <div className="col-span-4">Vehicle</div>
          <div className="col-span-3">VIN</div>
          <div className="col-span-2">Score</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-1 text-right">Open</div>
        </div>

        {(data ?? []).map((r) => (
          <div key={r.id} className="grid grid-cols-12 gap-2 px-5 py-4 border-t border-white/10 text-sm">
            <div className="col-span-4 text-white/80">{r.inventory?.year ?? ""} {r.inventory?.make ?? ""} {r.inventory?.model ?? ""}</div>
            <div className="col-span-3 text-white/70">{r.inventory?.vin}</div>
            <div className="col-span-2 text-[#C9A24A] font-semibold">
              {r.scores?.vindex_score ?? "—"} {r.scores?.band ? `• ${r.scores.band}` : ""}
            </div>
            <div className="col-span-2 text-white/70">{r.status}</div>
            <div className="col-span-1 text-right">
              <Link href={`/app/inspections/${r.id}`} className="underline text-white/80 hover:text-white">Open</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
