import { supabaseServer } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";

export default async function InspectionDetail({ params }: { params: { id: string } }) {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("org_id").eq("id", auth.user.id).single();

  const { data: insp } = await supabase
    .from("inspections")
    .select(`
      id, org_id, status,
      inventory:inventory_id(vin, year, make, model, trim, mileage),
      scores:scores(mii,sai,oci,cvm,vindex_score,band,confidence)
    `)
    .eq("id", params.id)
    .single();

  if (!insp) return notFound();
  if (profile?.org_id !== insp.org_id) return notFound();

  const { data: report } = await supabase
    .from("reports")
    .select("pdf_bucket,pdf_path,published_at")
    .eq("inspection_id", params.id)
    .single();

  let signedUrl: string | null = null;
  if (report?.pdf_bucket && report?.pdf_path) {
    const signed = await supabase.storage.from(report.pdf_bucket).createSignedUrl(report.pdf_path, 60 * 10);
    signedUrl = signed.data?.signedUrl ?? null;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Inspection</h1>
        <p className="mt-2 text-sm text-white/65">{insp.inventory?.year} {insp.inventory?.make} {insp.inventory?.model} • {insp.inventory?.vin}</p>
        <p className="mt-1 text-sm text-white/60">Status: {insp.status}</p>
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
        <p className="text-[11px] tracking-[0.35em] uppercase text-white/60">VINDEX Score™</p>
        <div className="mt-4 flex items-end justify-between flex-wrap gap-6">
          <div>
            <p className="text-5xl font-semibold text-[#C9A24A] leading-none">{insp.scores?.vindex_score ?? "—"}</p>
            <p className="mt-2 text-sm text-white/70">{insp.scores?.band ?? ""} • {insp.scores?.confidence ?? ""}</p>
          </div>
          <div className="text-sm text-white/60">
            <p>MII™ {insp.scores?.mii ?? "—"} • SAI™ {insp.scores?.sai ?? "—"} • OCI™ {insp.scores?.oci ?? "—"}</p>
            <p className="mt-1">CVM™ {insp.scores?.cvm ?? "—"}</p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <p className="text-sm font-semibold">Report</p>
        <p className="mt-2 text-sm text-white/60">Published: {report?.published_at ? new Date(report.published_at).toLocaleString() : "—"}</p>
        {signedUrl ? (
          <a href={signedUrl} className="mt-4 inline-flex rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm hover:bg-white/10">
            Download PDF
          </a>
        ) : (
          <p className="mt-3 text-sm text-white/60">Report not yet published.</p>
        )}
      </div>
    </div>
  );
}
