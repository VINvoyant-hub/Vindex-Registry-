"use server";
import { supabaseServer } from "@/lib/supabase/server";

export async function upsertResult(input: {
  inspection_id: string;
  item_code: string;
  severity: "PASS"|"MINOR"|"MODERATE"|"CRITICAL";
  notes?: string;
}) {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error("Unauthorized");

  const { data: insp } = await supabase.from("inspections").select("assigned_inspector").eq("id", input.inspection_id).single();
  if (insp?.assigned_inspector !== auth.user.id) throw new Error("Not assigned");

  const { error } = await supabase.from("checklist_results").upsert({
    inspection_id: input.inspection_id,
    item_code: input.item_code,
    severity: input.severity,
    notes: input.notes ?? null
  });

  if (error) throw new Error(error.message);
}

export async function submitInspection(inspection_id: string) {
  const supabase = supabaseServer();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error("Unauthorized");

  const { data: insp } = await supabase.from("inspections").select("assigned_inspector").eq("id", inspection_id).single();
  if (insp?.assigned_inspector !== auth.user.id) throw new Error("Not assigned");

  await supabase.from("inspections").update({ status: "submitted_by_inspector" }).eq("id", inspection_id);
  await supabase.from("ai_qc").upsert({ inspection_id, status: "pending", issues: [] });
  await supabase.from("inspections").update({ status: "ai_qc_in_review" }).eq("id", inspection_id);

  // Trigger AI-QC (best-effort; admin can also run)
  await fetch(`/api/ai-qc/run`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ inspection_id }),
  }).catch(() => {});
}
