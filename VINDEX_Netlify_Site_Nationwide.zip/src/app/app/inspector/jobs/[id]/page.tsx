"use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { upsertResult, submitInspection } from "./actions";

type Item = { code: string; layer: string; title: string; description: string | null };

export default function InspectorJob({ params }: { params: { id: string } }) {
  const [items, setItems] = useState<Item[]>([]);
  const [saving, setSaving] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const supabase = supabaseBrowser();
      const { data } = await supabase.from("checklist_items").select("code,layer,title,description").order("code");
      setItems((data ?? []) as any);
    })();
  }, []);

  async function uploadEvidence(file: File) {
    setMsg(null);
    const supabase = supabaseBrowser();
    const path = `${params.id}/${Date.now()}-${file.name}`;
    const up = await supabase.storage.from("inspection-evidence").upload(path, file, { upsert: false });
    if (up.error) return setMsg(up.error.message);

    const ins = await supabase.from("evidence").insert({
      inspection_id: params.id,
      kind: file.type.startsWith("video") ? "video" : "photo",
      bucket: "inspection-evidence",
      path,
      caption: null
    });
    if (ins.error) return setMsg(ins.error.message);

    setMsg("Evidence uploaded.");
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Inspection Job</h1>

      <div className="rounded-2xl border border-white/10 bg-white/5 p-5 space-y-3">
        <p className="text-sm font-semibold">Evidence Upload</p>
        <input type="file" accept="image/*,video/*" onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) uploadEvidence(f);
        }} />
        {msg ? <p className="text-sm text-white/70">{msg}</p> : null}
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
        <p className="text-sm font-semibold">Checklist (CVP™ 147)</p>
        <p className="mt-1 text-sm text-white/60">Select severity. Saves instantly.</p>

        <div className="mt-4 space-y-3">
          {items.map((it) => (
            <div key={it.code} className="rounded-xl border border-white/10 bg-black/30 p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-[#C9A24A]">{it.code} • {it.title}</p>
                  <p className="text-xs text-white/60">{it.layer}</p>
                </div>

                <select
                  className="rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm"
                  onChange={async (e) => {
                    const severity = e.target.value as any;
                    setSaving(it.code);
                    await upsertResult({ inspection_id: params.id, item_code: it.code, severity });
                    setSaving(null);
                  }}
                  defaultValue="PASS"
                >
                  <option value="PASS">PASS</option>
                  <option value="MINOR">MINOR</option>
                  <option value="MODERATE">MODERATE</option>
                  <option value="CRITICAL">CRITICAL</option>
                </select>
              </div>

              {saving === it.code ? <p className="mt-2 text-xs text-white/60">Saving…</p> : null}
            </div>
          ))}
        </div>

        <button
          onClick={async () => {
            setMsg(null);
            await submitInspection(params.id);
            setMsg("Submitted for AI QC + Admin Review.");
          }}
          className="mt-5 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm hover:bg-white/10"
        >
          Submit Inspection
        </button>

        {msg ? <p className="mt-3 text-sm text-white/70">{msg}</p> : null}
      </div>
    </div>
  );
}
