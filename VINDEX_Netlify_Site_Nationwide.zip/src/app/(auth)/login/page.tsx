"use client";

import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const router = useRouter();

  async function onLogin() {
    setErr(null);
    const supabase = supabaseBrowser();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return setErr(error.message);
    router.push("/app/dashboard");
  }

  return (
    <main className="min-h-screen bg-[#050608] text-white">
      <div className="mx-auto max-w-md px-6 py-16">
        <h1 className="text-3xl font-semibold">Authorized Access Only</h1>
        <p className="mt-2 text-sm text-white/60">Invite-only portals for dealers, flippers, auctions, inspectors, and admin.</p>

        <div className="mt-8 space-y-4 rounded-2xl border border-white/10 bg-white/5 p-6">
          <input className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm"
            placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <input className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm"
            placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
          {err ? <p className="text-sm text-[#C9A24A]">{err}</p> : null}
          <button onClick={onLogin}
            className="w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm hover:bg-white/10">
            Sign In
          </button>
        </div>
      </div>
    </main>
  );
}
