import "./globals.css";

export const metadata = {
  title: "VINDEX Registry",
  description: "National vehicle condition verification authority. Verify Beyond Guesswork™",
  manifest: "/manifest.json",
  themeColor: "#050608",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "VINDEX" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icons/icon-192.png" />
        <meta name="theme-color" content="#050608" />
      </head>
      <body>{children}</body>
    </html>
  );
}
