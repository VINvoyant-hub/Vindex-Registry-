const withPWA = require("@ducanh2912/next-pwa").default({
  dest: "public",
  register: true,
  skipWaiting: true,
  disable: process.env.NODE_ENV === "development",
  cacheOnFrontEndNav: true,
  aggressiveFrontEndNavCaching: true,
  fallbacks: { document: "/offline" },
  workboxOptions: {
    runtimeCaching: [
      {
        urlPattern: ({ request }) => request.destination === "image",
        handler: "CacheFirst",
        options: {
          cacheName: "images",
          expiration: { maxEntries: 200, maxAgeSeconds: 60 * 60 * 24 * 30 },
        },
      },
      {
        urlPattern: ({ url }) =>
          url.hostname.includes("supabase.co") && url.pathname.includes("/storage/v1/"),
        handler: "NetworkFirst",
        options: {
          cacheName: "supabase-storage",
          expiration: { maxEntries: 80, maxAgeSeconds: 60 * 60 * 24 * 7 },
        },
      },
      {
        urlPattern: ({ url }) => url.pathname.startsWith("/api/"),
        handler: "NetworkFirst",
        options: {
          cacheName: "api",
          expiration: { maxEntries: 80, maxAgeSeconds: 60 * 10 },
        },
      },
    ],
  },
});

module.exports = withPWA({
  reactStrictMode: true,
});
